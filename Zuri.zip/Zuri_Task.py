num1 = 10
num2 = 15

num3 = num1 + num2
print(num3)
