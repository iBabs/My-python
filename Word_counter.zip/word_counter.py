fawz = input("Enter any sentence: ")
fahm = fawz.split(" ")

print(len(fahm))
